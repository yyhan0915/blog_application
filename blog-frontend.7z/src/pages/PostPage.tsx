import React from 'react';

const PostPage = () => {
    return <div>포스트읽기</div>;
};

export default PostPage;
