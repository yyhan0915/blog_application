import React from 'react';
import Header from '../components/common/Header';

const PostListPage = () => {
    return (
        <>
            <Header />
            <div>안녕하세요</div>
        </>
    );
};

export default PostListPage;
